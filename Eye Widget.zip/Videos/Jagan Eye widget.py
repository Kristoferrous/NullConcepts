import sys
import math
import random
import time
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget
from PyQt6.QtCore import Qt, QPoint, QRect, QTimer, QUrl
from PyQt6.QtGui import QPainter, QColor, QPen, QBitmap, QPainterPath, QRegion, QRadialGradient, QFont, QBrush

class CircularWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Circular Window")
        self.setFixedSize(400, 400)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        # Create circular mask for clickable area
        mask = QBitmap(400, 400)
        mask.fill(Qt.GlobalColor.color0)
        painter = QPainter(mask)
        painter.setBrush(Qt.GlobalColor.color1)
        painter.drawEllipse(0, 0, 400, 400)
        painter.end()
        self.setMask(mask)

        # Eye state
        self.eye_open = False
        self.eye_transition = 0.0  # 0.0 = closed, 1.0 = fully open
        self.blink_timer = QTimer()
        self.blink_timer.timeout.connect(self.update_eye_transition)
        self.blink_timer.setInterval(20)  # Faster updates for smoother animation
        
        # Mouse tracking
        self.drag_start_pos = None
        self.is_dragging = False
        
        # Glow effect
        self.glow_opacity = 0
        self.glow_timer = QTimer()
        self.glow_timer.timeout.connect(self.update_glow)
        self.glow_timer.setInterval(50)  # Smooth pulse animation
        self.glow_timer.start()
        
        # Fade effect for closed state
        self.fade_phase = 0
        self.fade_timer = QTimer()
        self.fade_timer.timeout.connect(self.update_fade)
        self.fade_timer.setInterval(50)
        self.fade_timer.start()
        
        # Tibetan text
        self.tibetan_chars = ["ཨོཾ", "མ་", "ཎི", "པདྨེ", "ཧཱུྃ", "ཨོཾ", "མ་", "ཎི", "པདྨེ", "ཧཱུྃ"]
        self.outer_tibetan_chars = ["ཨོཾ", "མ་", "ཎི", "པདྨེ", "ཧཱུྃ", "ཨོཾ", "མ་", "ཎི", "པདྨེ", "ཧཱུྃ"]
        self.middle_tibetan_chars = ["ཨོཾ", "མ་", "ཎི", "པདྨེ", "ཧཱུྃ", "ཨོཾ", "མ་", "ཎི", "པདྨེ", "ཧཱུྃ"]
        self.text_rotation = 0
        self.outer_text_rotation = 0
        self.middle_text_rotation = 0
        self.text_timer = QTimer()
        self.text_timer.timeout.connect(self.update_text_rotation)
        self.text_timer.setInterval(50)
        self.text_timer.start()
        
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setFocus()

    def update_eye_transition(self):
        if self.eye_open:
            if self.eye_transition < 1:
                self.eye_transition += 0.1  # Faster opening
                if self.eye_transition >= 1:
                    self.eye_transition = 1
        else:
            if self.eye_transition > 0:
                self.eye_transition -= 0.05  # Gradual closing
                if self.eye_transition <= 0:
                    self.eye_transition = 0
        self.update()

    def update_fade(self):
        self.fade_phase += 0.1
        if self.fade_phase >= 2 * math.pi:
            self.fade_phase = 0
        self.update()

    def update_text_rotation(self):
        if self.eye_open:
            # Inner ring rotates clockwise
            self.text_rotation += 0.5
            if self.text_rotation >= 360:
                self.text_rotation = 0
            # Middle ring rotates counter-clockwise
            self.middle_text_rotation -= 0.3
            if self.middle_text_rotation <= -360:
                self.middle_text_rotation = 0
            # Outer ring rotates counter-clockwise
            self.outer_text_rotation -= 0.7  # Slightly faster for visual interest
            if self.outer_text_rotation <= -360:
                self.outer_text_rotation = 0
            self.update()

    def keyPressEvent(self, event):
        self.last_key_time = time.time()
        self.blink_timer.start(20)
        self.update()

    def keyReleaseEvent(self, event):
        self.last_key_time = time.time()
        self.blink_timer.start(20)
        self.update()

    def update_glow(self):
        if self.eye_transition > 0:
            # Gentle pulse between 0.1 and 0.3 opacity
            self.glow_opacity = 0.1 + 0.2 * (math.sin(time.time() * 2) + 1) / 2
        else:
            self.glow_opacity = 0
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Draw gentle red glow when eye is open
        if self.eye_transition > 0 and self.glow_opacity > 0:
            glow_radius = 100  # Size of the glow
            gradient = QRadialGradient(200, 200, glow_radius)
            gradient.setColorAt(0, QColor(255, 0, 0, int(self.glow_opacity * 255 * 0.3 * self.eye_transition)))  # Center
            gradient.setColorAt(0.5, QColor(255, 0, 0, int(self.glow_opacity * 255 * 0.2 * self.eye_transition)))  # Middle
            gradient.setColorAt(1, QColor(255, 0, 0, 0))  # Edge
            painter.setBrush(gradient)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(200 - glow_radius, 200 - glow_radius, 
                              glow_radius * 2, glow_radius * 2)

        # Draw inner Tibetan text circle
        inner_radius = 85  # Buffer from eye
        center_x, center_y = 200, 200  # New center point
        
        for i, char in enumerate(self.tibetan_chars):
            base_angle = (2 * math.pi * i / len(self.tibetan_chars))
            if self.eye_open:
                angle = base_angle + math.radians(self.text_rotation)
            else:
                angle = base_angle
            
            x = center_x + inner_radius * math.cos(angle)
            y = center_y + inner_radius * math.sin(angle)
            
            font = QFont("Noto Sans Tibetan", 12)
            painter.setFont(font)
            painter.setPen(QPen(QColor(255, 255, 255), 1))
            
            painter.save()
            painter.translate(x, y)
            painter.rotate(math.degrees(angle) + 90)
            painter.drawText(0, 0, char)
            painter.restore()

        # Draw middle Tibetan text circle when eye is open
        if self.eye_open:
            middle_radius = 110  # Adjusted to maintain spacing
            for i, char in enumerate(self.middle_tibetan_chars):
                base_angle = (2 * math.pi * i / len(self.middle_tibetan_chars))
                angle = base_angle + math.radians(self.middle_text_rotation)
                
                x = center_x + middle_radius * math.cos(angle)
                y = center_y + middle_radius * math.sin(angle)
                
                font = QFont("Noto Sans Tibetan", 12)
                painter.setFont(font)
                painter.setPen(QPen(QColor(255, 255, 255), 1))
                
                painter.save()
                painter.translate(x, y)
                painter.rotate(math.degrees(angle) + 90)
                painter.drawText(0, 0, char)
                painter.restore()

        # Draw outer Tibetan text circle when eye is open
        if self.eye_open:
            outer_radius = 145  # Adjusted to maintain spacing
            for i, char in enumerate(self.outer_tibetan_chars):
                base_angle = (2 * math.pi * i / len(self.outer_tibetan_chars))
                angle = base_angle + math.radians(self.outer_text_rotation)
                
                x = center_x + outer_radius * math.cos(angle)
                y = center_y + outer_radius * math.sin(angle)
                
                font = QFont("Noto Sans Tibetan", 12)
                painter.setFont(font)
                painter.setPen(QPen(QColor(255, 255, 255), 1))
                
                painter.save()
                painter.translate(x, y)
                painter.rotate(math.degrees(angle) + 90)
                painter.drawText(0, 0, char)
                painter.restore()

        # Draw single thick white circle
        painter.setPen(QPen(QColor(255, 255, 255), 3))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(130, 130, 140, 140)

        if self.eye_transition > 0:
            # Draw irregular black concentric circle with brush stroke effect
            # Base circle
            painter.setPen(QPen(QColor(0, 0, 0), 6))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawEllipse(135, 135, 130, 130)
            
            # Offset variations for brush stroke effect
            offsets = [(0, 0), (1, 1), (-1, -1), (2, 0), (0, 2), (-2, 0), (0, -2)]
            for dx, dy in offsets:
                painter.setPen(QPen(QColor(0, 0, 0), random.randint(4, 7)))
                painter.drawEllipse(135 + dx, 135 + dy, 130, 130)

            # Draw concentric circles with transition
            for i in range(2):
                if i == 0:  # Innermost circle
                    circle_size = int(20 * self.eye_transition)
                    painter.setPen(QPen(QColor(255, 255, 255), 1))
                else:  # Middle circle
                    circle_size = int(28 * self.eye_transition)
                    painter.setPen(QPen(QColor(255, 255, 255), 1))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawEllipse(200 - circle_size//2, 200 - circle_size//2, circle_size, circle_size)

            # Draw almond eye outline with transition
            path = QPainterPath()
            start_y = 200
            control_y = 160 + (40 * (1 - self.eye_transition))
            end_y = 200
            path.moveTo(140, start_y)
            path.quadTo(200, control_y, 260, end_y)
            path.quadTo(200, 240 - (40 * (1 - self.eye_transition)), 140, start_y)
            painter.setPen(QPen(QColor(255, 255, 255), 3))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawPath(path)
        else:
            # Draw regular black circle when eye is closed
            painter.setPen(QPen(QColor(0, 0, 0), 4))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawEllipse(135, 135, 130, 130)

            # Draw regular text circles
            painter.setPen(QPen(QColor(255, 255, 255), 2))
            painter.drawEllipse(187, 187, 25, 25)
            painter.drawEllipse(192, 192, 15, 15)

        # Draw central black circle
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(0, 0, 0))
        painter.drawEllipse(180, 180, 40, 40)

        if self.eye_transition > 0:
            # Draw almond eye outline with transition
            path = QPainterPath()
            start_y = 200
            control_y = 160 + (40 * (1 - self.eye_transition))  # Transition control point
            end_y = 200
            path.moveTo(140, start_y)
            path.quadTo(200, control_y, 260, end_y)
            path.quadTo(200, 240 - (40 * (1 - self.eye_transition)), 140, start_y)
            painter.setPen(QPen(QColor(255, 255, 255), 3))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawPath(path)
            
            # Draw concentric circles with transition
            for i in range(2):
                if i == 0:  # Innermost circle
                    circle_size = int(20 * self.eye_transition)
                    painter.setPen(QPen(QColor(255, 255, 255), 1))
                else:  # Middle circle
                    circle_size = int(28 * self.eye_transition)
                    painter.setPen(QPen(QColor(255, 255, 255), 1))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawEllipse(200 - circle_size//2, 200 - circle_size//2, circle_size, circle_size)
        else:
            # Draw closed almond eye
            path = QPainterPath()
            path.moveTo(140, 200)
            path.quadTo(200, 205, 260, 200)
            painter.setPen(QPen(QColor(255, 255, 255), 3))
            painter.drawPath(path)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            # Store the global click position for accurate dragging
            self.drag_start_pos = event.globalPosition().toPoint()
            self.is_dragging = False
        elif event.button() == Qt.MouseButton.RightButton:
            QApplication.instance().quit()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if not self.is_dragging:
                # Only toggle if we weren't dragging
                self.eye_open = not self.eye_open
                self.blink_timer.start(20)
                self.update()
            self.drag_start_pos = None
            self.is_dragging = False

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.MouseButton.LeftButton and self.drag_start_pos is not None:
            # Get the current global position
            current_pos = event.globalPosition().toPoint()
            # Calculate the movement delta
            delta = current_pos - self.drag_start_pos
            
            # If we've moved at least 2 pixels, start dragging
            if not self.is_dragging and delta.manhattanLength() > 2:
                self.is_dragging = True
            
            if self.is_dragging:
                # Move the window directly using the delta
                window = self.window()
                window.move(window.pos() + delta)
                # Update the start position for the next move
                self.drag_start_pos = current_pos

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.circular_widget = CircularWindow()
        self.setCentralWidget(self.circular_widget)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(400, 400)
        
        # Center the window on the screen
        screen = QApplication.primaryScreen().geometry()
        x = (screen.width() - self.width()) // 2
        y = (screen.height() - self.height()) // 2
        self.move(x, y)

    def mousePressEvent(self, event):
        self.circular_widget.mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.circular_widget.mouseReleaseEvent(event)

    def mouseMoveEvent(self, event):
        self.circular_widget.mouseMoveEvent(event)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    window.circular_widget.setFocus()
    sys.exit(app.exec()) 